sampleApp.factory('Geek', ['$http', function($http) {

	

}]);